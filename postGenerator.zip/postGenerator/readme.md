# Post Generator

Post Generator is a WordPress plugin that uses the OpenAI API to generate posts dynamically based on user input.

## Installation

**Clone or Download the Repository:**  
   Place the project folder in your WordPress `plugins` directory.

   ```bash
   cd wp-content/plugins
   git clone
   composer install